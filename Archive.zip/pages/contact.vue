<template>
  <main>
      <section class="contact">
          <div class="title_section">

          </div>
      </section>
      <newsletter/>
  </main>
</template>

<script>
import Newsletter from '../components/default/Newsletter'
export default {
    components: {
        Newsletter,
    }

}
</script>

<style>

</style>