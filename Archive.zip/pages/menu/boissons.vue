<template>
  <main>
    <div class="top_bar_fixed">
      <div class="container_items">
        <div class="title">
          <p>Catégories</p>
        </div>
        <div class="items">
          <nuxt-link to="/menu/tapas">Tapas</nuxt-link>
          <nuxt-link to="/menu/plats">Plats</nuxt-link>
          <nuxt-link to="/menu/desserts">Desserts</nuxt-link>
          <nuxt-link to="/menu/boissons">Boissons</nuxt-link>
          <nuxt-link to="/menu/vins">Vins</nuxt-link>
          <nuxt-link to="/menu/rhum">Rhum</nuxt-link>
        </div>
      </div>
    </div>
    <section class="menu">
      <div class="blackBody">
        <div class="title">
          <h2>Apéritifs</h2>
        </div>
      </div>
      <div class="elements_menu">
        <p class="content">Spiritueux 10cl</p>
        <span></span>
        <p class="price">5.00€</p>
      </div>

      <div class="elements_menu">
        <p class="content">Martini blanc ou rouge</p>
        <span></span>
        <p class="price">5,00€</p>
      </div>
      <div class="elements_menu">
        <p class="content">Kir</p>
        <span></span>
        <p class="price">5,00€</p>
      </div>
      <div class="elements_menu">
        <p class="content">Lillet Blanc, porto</p>
        <span></span>
        <p class="price">5,00€</p>
      </div>
      <div class="elements_menu">
        <p class="content">Anis 5cl</p>
        <span></span>
        <p class="price">4,00€</p>
      </div>
      <div class="blackBody">
        <div class="title">
          <h2>Alcools et digestifs 5cl</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Cognac, Armagnac, Calvados, Eaux de vie
          </p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Rhum, Whisky, Gin, Vodka
          </p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Manzana, Limoncello, Get 27
          </p>
          <span></span>
          <p class="price">5,50€</p>
        </div>
      </div>
      <div class="blackBody_1">
        <div class="title">
          <h2>Boissons Chaudes</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Expresso
          </p>
          <span></span>
          <p class="price">2,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Chocolat
          </p>
          <span></span>
          <p class="price">4,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Double expresso
          </p>
          <span></span>
          <p class="price">3,50€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Thé vert menthe
          </p>
          <span></span>
          <p class="price">3,50€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Grand crème
          </p>
          <span></span>
          <p class="price">4,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Infusion
          </p>
          <span></span>
          <p class="price">3,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Cappuccino
          </p>
          <span></span>
          <p class="price">4,50€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Irish coffee
          </p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
      <div class="blackBody_1">
        <div class="title">
          <h2>Boissons fraiches</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Sirops
          </p>
          <span></span>
          <p class="price">2,60€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Limonade
          </p>
          <span></span>
          <p class="price">3,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Diabolo
          </p>
          <span></span>
          <p class="price">3,30€</p>
        </div>
        <p class="description">
          Citron, fraise, grenadine, menthe, pêche, orgeat.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Soda 33cl
          </p>
          <span></span>
          <p class="price">3,60€</p>
        </div>
        <p class="description">
          Coca, Coca Zéro, Orangina, Ice Tea, Oasis, Schweppes, argrume et
          tonic.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Perrier 33cl
          </p>
          <span></span>
          <p class="price">3,60€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Pago 33cl
          </p>
          <span></span>
          <p class="price">4,50€</p>
        </div>
        <p class="description">
          Orange, ananas, pomme.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Eau Plate Abatilles 50cl
          </p>
          <span></span>
          <p class="price">2,90€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Eau Plate Abatilles 1L
          </p>
          <span></span>
          <p class="price">4,50€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Eau Gazeuse Abatilles 50cl
          </p>
          <span></span>
          <p class="price">3,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Eau Gazeuse Abatilles 1L
          </p>
          <span></span>
          <p class="price">4,60€</p>
        </div>
      </div>
      <div class="blackBody">
        <div class="title">
          <h2>Macario italian retro drink</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Limonata
          </p>
          <span></span>
          <p class="price">5,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Thé citron
          </p>
          <span></span>
          <p class="price">5,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Thé pêche
          </p>
          <span></span>
          <p class="price">5,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Thé menthe
          </p>
          <span></span>
          <p class="price">5,00€</p>
        </div>
      </div>
      <div class="blackBody">
        <div class="title">
          <h2>Bières pression</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Morretti <span class="ligther">(Demi 25cl)</span>
          </p>
          <span></span>
          <p class="price">3,70€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Morretti <span class="ligther">(Pinte 50cl)</span>
          </p>
          <span></span>
          <p class="price">7,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Leffe <span class="ligther">(Demi 25cl)</span></p>
          <span></span>
          <p class="price">4,50€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Leffe <span class="ligther">(Pinte 50cl)</span></p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
      <div class="blackBody">
        <div class="title">
          <h2>Bières bouteilles</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Hoegaarden blanche, Desperado 33cl</p>
          <span></span>
          <p class="price">6,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Corona 35.5cl</p>
          <span></span>
          <p class="price">6,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Bière blonde italienne</p>
          <span></span>
          <p class="price">6,00€</p>
        </div>
         <p class="description">
          Birra Antoniana
        </p>
      </div>
       <div class="blackBody_1">
        <div class="title">
          <h2>Cocktails</h2>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Pinà colada</p>
          <span></span>
          <p class="price">10,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">London Mule</p>
          <span></span>
          <p class="price">9,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Moscow Mule</p>
          <span></span>
          <p class="price">9,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Mojito</p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Ti-punch</p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Planteur maison</p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Caïpirinha</p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Spritz</p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Americano</p>
          <span></span>
          <p class="price">8,00€</p>
        </div>
      </div>
      <div class="blackBody_1">
        <div class="title">
          <h2>Cocktails sans alcools</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Virgin Mojito</p>
          <span></span>
          <p class="price">6,00€</p>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">Cocktail de jus de fruits</p>
          <span></span>
          <p class="price">6,00€</p>
        </div>
      </div>
      

    </section>
    <Newsletter />
  </main>
</template>

<script>
import Newsletter from '../../components/default/Newsletter'
export default {
  components: {
    Newsletter
  }
}
</script>

<style scoped>
.ligther {
  font-weight: lighter;
  background-color: transparent !important;
}

.top_bar_fixed {
  position: fixed;
  right: 0;
  left: 0;
  top: 70px;
  height: 50px;
  background-color: var(--background);
  border-bottom: 1px solid #e0e0e0;
}

.container_items {
  height: 110px;
  overflow-x: scroll;
  background-color: var(--background);
  display: flex;
  flex-flow: column nowrap;
  border-bottom: 1px solid #e0e0e0;

  padding: 40px 0px 10px 20px;
}

.title p {
  color: var(--body);
  font-weight: bold;
  font-size: 14px;
}

.items {
  display: flex;
  margin-top: 10px;
  padding-bottom: 15px;
  overflow-x: scroll;
  flex-flow: row nowrap;
}

.items a {
  margin-right: 10px;
  text-decoration: none;
  color: var(--black);
  font-weight: bold;
  font-family: 'Noto', serif;
}

.nuxt-link-active {
  color: var(--redBody) !important;
  font-weight: bold !important;
}

.item_img {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 30px;
  height: 30px;
}

.item_img img {
  width: 100%;
}

.menu {
  padding: 150px 0 30px 0;
  background-image: url('~assets/img/jpg/back_bois.png');
  background-repeat: repeat;
  background-size: 100%;
}

.blackBody {
  padding: 20px;
  margin-top: 30px;
  margin-bottom: 20px;
  border-bottom: 2px solid var(--black);
  border-top: 2px solid var(--black);
}

.blackBody .title h2 {
  text-align: center;
  color: var(--black);
  font-size: 24px;
  font-style: italic;
  font-weight: bold;
  text-transform: uppercase;
  font-family: 'Times New Roman', Times, serif, sans-serif;
}

.blackBody_1 {
  padding: 20px;
  margin-top: 30px;
  margin-bottom: 20px;
  border-bottom: 2px solid var(--black);
  border-top: 2px solid var(--black);
}

.blackBody_1 .title h2 {
  text-align: center;
  color: var(--black);
  font-size: 24px;
  text-transform: none;
  font-family: 'italic-title', sans-serif;
}

.redBackground_1 {
  background-color: var(--redBody);
  padding: 20px;
  margin-top: 30px;
  border-top: 2px solid var(--black);
  margin-bottom: 20px;
  border-bottom: 2px solid var(--black);
}

.redBackground_1 .title h2 {
  text-align: center;
  color: var(--white);
  font-size: 28px;
  font-weight: bold;
  text-transform: none;
  font-family: 'italic-title';
}

.greenBody {
  border-top: 2px solid var(--black);
  padding: 20px;
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.greenBody .title h2 {
  text-align: center;
  color: var(--green);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.redBody {
  border-top: 2px solid var(--black);
  padding: 20px;
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.redBody .title h2 {
  text-align: center;
  color: var(--redBody);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.greenBackground {
  border-top: 2px solid var(--black);
  padding: 20px;
  background-color: var(--green);
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.greenBackground .title h2 {
  text-align: center;
  color: var(--white);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.elements_menu {
  display: flex;
  margin: 5px 20px;
  justify-content: space-between;
  align-items: flex-end;
}

.elements_menu .content {
  width: 100%;
  color: var(--black);
  font-weight: bold;
}

.elements_menu span {
  height: 1px;
  margin-right: 10px;
  border: none;
  margin-bottom: 7px;
  background-color: var(--black);
}

.elements_menu .price {
  color: var(--black);
  font-weight: lighter;
}

.content_menu .description {
  font-size: 12px;
  font-weight: lighter;
  margin: -5px 20px 0 20px;
  line-height: 20px;
  color: var(--black);
}

.accompagnement {
  margin: 10px 20px;
}

.accompagnement p {
  color: var(--redBody);
  font-size: lighter;
}

.accompagnement_green {
  margin: 10px 20px;
}

.accompagnement_green p {
  color: var(--green);
  font-size: lighter;
}
</style>
