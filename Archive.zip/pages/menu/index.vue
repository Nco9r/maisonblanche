<template>
  <main>
      <section class="menu">  
        ici le menu
      </section>
      <Newsletter/>
  </main>
</template>

<script>
import Newsletter from '../../components/default/Newsletter'
export default {
  components: {
    Newsletter,
  }
}
</script>

<style scoped>

</style>