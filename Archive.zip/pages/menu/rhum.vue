<template>
  <main>
    <div class="top_bar_fixed">
      <div class="container_items">
        <div class="title">
          <p>Catégories</p>
        </div>
        <div class="items">
          <nuxt-link to="/menu/tapas">Tapas</nuxt-link>
          <nuxt-link to="/menu/plats">Plats</nuxt-link>
          <nuxt-link to="/menu/desserts">Desserts</nuxt-link>
          <nuxt-link to="/menu/boissons">Boissons</nuxt-link>
          <nuxt-link to="/menu/vins">Vins</nuxt-link>
          <nuxt-link to="/menu/rhum">Rhum</nuxt-link>
        </div>
      </div>
    </div>
    <section class="menu">
      <div class="rhumBackground">
        <div class="title">
          <h2>Amérique du sud</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Botran
          </p>
          <span></span>
          <p class="price">12,00€</p>
        </div>
        <p class="description">
          18 ans, Guatemala.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Abuelo
          </p>
          <span></span>
          <p class="price">13,00€</p>
        </div>
        <p class="description">
          15 ans, finish napoléon, Panama.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Millionario XO
          </p>
          <span></span>
          <p class="price">17,00€</p>
        </div>
        <p class="description">
          Pérou
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Coloma
          </p>
          <span></span>
          <p class="price">12,50€</p>
        </div>
        <p class="description">
          15 ans, Colombie
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Ron Esclavo XO
          </p>
          <span></span>
          <p class="price">13,00€</p>
        </div>
        <p class="description">
          République Dominicaine
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Santissima
          </p>
          <span></span>
          <p class="price">12,50€</p>
        </div>
        <p class="description">
          15 ans, Cuba
        </p>
      </div>
      <div class="rhumBackground">
        <div class="title">
          <h2>Pacifique</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Manutea VO
          </p>
          <span></span>
          <p class="price">13,00€</p>
        </div>
        <p class="description">
          Tahiti.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Marama
          </p>
          <span></span>
          <p class="price">9,00€</p>
        </div>
        <p class="description">
          Fidji.
        </p>
      </div>
      <div class="rhumBackground">
        <div class="title">
          <h2>Océan Indien</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Rivière du mat
          </p>
          <span></span>
          <p class="price">12,50€</p>
        </div>
        <p class="description">
          2006, Reunion.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Chamarel XO
          </p>
          <span></span>
          <p class="price">15,00€</p>
        </div>
        <p class="description">
          Le Maurice
        </p>
      </div>
      <div class="rhumBackground">
        <div class="title">
          <h2>Océanie</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Naga pearl of Djakarta
          </p>
          <span></span>
          <p class="price">11,50€</p>
        </div>
        <p class="description">
          Indénosie.
        </p>
      </div>
      <div class="rhumBackground">
        <div class="title">
          <h2>Antilles</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Doorlys
          </p>
          <span></span>
          <p class="price">15,50€</p>
        </div>
        <p class="description">
          14 ans, Barbade.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Plantation
          </p>
          <span></span>
          <p class="price">13,00€</p>
        </div>
        <p class="description">
          20th anniversary, Barbade.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Admiral Rodney royal aok
          </p>
          <span></span>
          <p class="price">13,50€</p>
        </div>
        <p class="description">
          St Lucie.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Hampden
          </p>
          <span></span>
          <p class="price">13,50€</p>
        </div>
        <p class="description">
          Jamaique.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Worthy Park single estate
          </p>
          <span></span>
          <p class="price">12,50€</p>
        </div>
        <p class="description">
          Jamaique.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Black Tot finest Caribbean
          </p>
          <span></span>
          <p class="price">11,00€</p>
        </div>
        <p class="description">
          Caraibes.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Séverin XO
          </p>
          <span></span>
          <p class="price">15,00€</p>
        </div>
        <p class="description">
          Guadeloupe.
        </p>
      </div>
      <div class="rhumBackground">
        <div class="title">
          <h2>Afrique</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Dzama cuvée noir
          </p>
          <span></span>
          <p class="price">10,50€</p>
        </div>
        <p class="description">
          Madagascar.
        </p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Mhoba rum american aok
          </p>
          <span></span>
          <p class="price">10,50€</p>
        </div>
        <p class="description">
          Afrique du sud.
        </p>
      </div>
      <div class="rhumBackground">
        <div class="title">
          <h2>Europe</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Dos Madeiras seleccion
          </p>
          <span></span>
          <p class="price">12,50€</p>
        </div>
        <p class="description">
          Espagne.
        </p>
      </div>
    </section>
    <Newsletter />
  </main>
</template>

<script>
import Newsletter from '../../components/default/Newsletter'
export default {
  components: {
    Newsletter
  }
}
</script>

<style scoped>
.nuxt-link-active {
  color: var(--redBody) !important;
  font-weight: bold !important;
}

.top_bar_fixed {
  position: fixed;
  right: 0;
  left: 0;
  top: 70px;
  height: 50px;
  background-color: var(--background);
  border-bottom: 1px solid #e0e0e0;
}

.container_items {
  height: 110px;
  overflow-x: scroll;
  background-color: var(--background);
  display: flex;
  flex-flow: column nowrap;
  border-bottom: 1px solid #e0e0e0;

  padding: 40px 0px 10px 20px;
}

.title p {
  color: var(--body);
  font-weight: bold;
  font-size: 14px;
}

.items {
  display: flex;
  margin-top: 10px;
  padding-bottom: 15px;
  overflow-x: scroll;
  flex-flow: row nowrap;
}

.items a {
  margin-right: 10px;
  text-decoration: none;
  color: var(--black);
  font-weight: bold;
  font-family: 'Noto', serif;
}

.nuxt-link-active {
  color: var(--redBody) !important;
  font-weight: bold !important;
}

.item_img {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 30px;
  height: 30px;
}

.item_img img {
  width: 100%;
}

.menu {
  padding: 150px 0 30px 0;
  background-image: url('~assets/img/jpg/back_bois.png');
  background-repeat: repeat;
  background-size: 100%;
}

.rhumBackground {
  padding: 20px;
  margin-top: 30px;
  margin-bottom: -10px;
}

.rhumBackground .title h2 {
  color: var(--green-rhum);
  font-size: 24px;
  font-weight: bold;
  text-transform: none;
}

.redBackground_1 {
  background-color: var(--redBody);
  padding: 20px;
  margin-top: 30px;
  border-top: 2px solid var(--black);
  margin-bottom: 20px;
  border-bottom: 2px solid var(--black);
}

.redBackground_1 .title h2 {
  text-align: center;
  color: var(--white);
  font-size: 28px;
  font-weight: bold;
  text-transform: none;
  font-family: 'italic-title';
}

.greenBody {
  border-top: 2px solid var(--black);
  padding: 20px;
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.greenBody .title h2 {
  text-align: center;
  color: var(--green);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.redBody {
  border-top: 2px solid var(--black);
  padding: 20px;
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.redBody .title h2 {
  text-align: center;
  color: var(--redBody);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.greenBackground {
  border-top: 2px solid var(--black);
  padding: 20px;
  background-color: var(--green);
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.greenBackground .title h2 {
  text-align: center;
  color: var(--white);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.elements_menu {
  display: flex;
  margin: 5px 20px;
  justify-content: space-between;
  align-items: flex-end;
}

.elements_menu .content {
  width: 100%;
  color: var(--black);
  font-weight: bold;
}

.elements_menu span {
  height: 1px;
  margin-right: 10px;
  border: none;
  margin-bottom: 7px;
  background-color: var(--black);
}

.elements_menu .price {
  color: var(--black);
  font-weight: lighter;
}

.content_menu .description {
  font-size: 12px;
  font-weight: lighter;
  margin: -5px 20px 0 20px;
  line-height: 20px;
  color: var(--black);
}

.accompagnement {
  margin: 10px 20px;
}

.accompagnement p {
  color: var(--redBody);
  font-size: lighter;
}

.accompagnement_green {
  margin: 10px 20px;
}

.accompagnement_green p {
  color: var(--green);
  font-size: lighter;
}
</style>
