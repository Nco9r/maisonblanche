<template>
  <main>
    <div class="top_bar_fixed">
      <div class="container_items">
        <div class="title">
          <p>Catégories</p>
        </div>
        <div class="items">
          <nuxt-link to="/menu/tapas">Tapas</nuxt-link>
          <nuxt-link to="/menu/plats">Plats</nuxt-link>
          <nuxt-link to="/menu/desserts">Desserts</nuxt-link>
          <nuxt-link to="/menu/boissons">Boissons</nuxt-link>
          <nuxt-link to="/menu/vins">Vins</nuxt-link>
          <nuxt-link to="/menu/rhum">Rhum</nuxt-link>
        </div>
      </div>
    </div>
    <section class="menu">
      <div class="blackBody">
        <div class="title">
          <h2>Les vins blancs</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Blanc de l'impératrice
            <span class="ligther">(blanc moelleux)</span> 75cl
          </p>
          <span></span>
          <p class="price">20.00€</p>
        </div>
        <p class="description">IGP des Landes</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Blanc de l'impératrice
            <span class="ligther">(Blanc moelleux)</span>au verre 12cl
          </p>
          <span></span>
          <p class="price">4.50€</p>
        </div>
        <p class="description">IGP des Landes</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Gaillot Fournier
            <span class="ligther">(Blanc sec)</span> 75cl
          </p>
          <span></span>
          <p class="price">18.00€</p>
        </div>
        <p class="description">Entre-deux-mers</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Gaillot Fournier <span class="ligther">(Blanc sec)</span>au
            verre 12cl
          </p>
          <span></span>
          <p class="price">4.00€</p>
        </div>
        <p class="description">Entre-deux-mers</p>
      </div>
      <div class="blackBody">
        <div class="title">
          <h2>Les vins rosés</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Le pichet cuvée des Princes de Roubine 50cl
          </p>
          <span></span>
          <p class="price">11.50€</p>
        </div>
        <p class="description">Vin de France</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Le piché cuvée des Princes de Roubine au verre 12cl
          </p>
          <span></span>
          <p class="price">4.00€</p>
        </div>
        <p class="description">Vin de France</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Cuvée des Princes de Roubine 75cl
          </p>
          <span></span>
          <p class="price">16.00€</p>
        </div>
        <p class="description">Vin de France</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Haut-Calens 75cl
          </p>
          <span></span>
          <p class="price">18.00€</p>
        </div>
        <p class="description">AOC Bordeaux Graves</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Roubine La Vie en Rose 75cl
          </p>
          <span></span>
          <p class="price">25.00€</p>
        </div>
        <p class="description">AOP Côtes de Provences</p>
      </div>

      <div class="blackBody">
        <div class="title">
          <h2>Les vins Rouges</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Le pichet Château Haut Philipon 50cl
          </p>
          <span></span>
          <p class="price">11.50€</p>
        </div>
        <p class="description">AOC Bordeaux</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Haut Philipon au verre 12cl
          </p>
          <span></span>
          <p class="price">4.00€</p>
        </div>
        <p class="description">AOC Bordeaux</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Joinin <span class="ligther">By Ch Pipeau</span> 75cl
          </p>
          <span></span>
          <p class="price">16.50€</p>
        </div>
        <p class="description">AOC Bordeaux</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Joinin <span class="ligther">By Ch Pipeau</span> au verre
            12cl
          </p>
          <span></span>
          <p class="price">4.50€</p>
        </div>
        <p class="description">AOC Bordeaux</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Haut-Calens 75cl
          </p>
          <span></span>
          <p class="price">21.00€</p>
        </div>
        <p class="description">AOC Bordeaux Graves</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Le pessac-Léognan de Chevalier 75cl
          </p>
          <span></span>
          <p class="price">34.00€</p>
        </div>
        <p class="description">AOC Pessac Léognan</p>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Château Pipeau
          </p>
          <span></span>
          <p class="price">47.00€</p>
        </div>
        <p class="description">AOC St Emilion Grand Cru</p>
      </div>
      <div class="blackBody">
        <div class="title">
          <h2>Les vins italiens</h2>
        </div>
      </div>
      <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            <span class="ligther">Opere 27</span>Lambrusco rosso 75cl
          </p>
          <span></span>
          <p class="price">18.00€</p>
        </div>
        <p class="description">Amabile Emilia IGT (Romagna)</p>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
              Caldora
            <span class="ligther">Sangiovese</span>75cl
          </p>
          <span></span>
          <p class="price">24.00€</p>
        </div>
        <p class="description">Terre di Chieti IGT (Albruzzo)</p>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
              Mesa
            <span class="ligther">Primo scuro Cannonau</span>75cl
          </p>
          <span></span>
          <p class="price">31.00€</p>
        </div>
        <p class="description">Di Sardegna DOC</p>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Antinori Santa Christina Chianti 75cl
          </p>
          <span></span>
          <p class="price">32.00€</p>
        </div>
        <p class="description">Superiore DOGG (Toscana)</p>
      </div>
      <div class="blackBody">
        <div class="title">
          <h2>Le Champagne</h2>
        </div>
      </div>
       <div class="content_menu">
        <div class="elements_menu">
          <p class="content">
            Champagne AYALA <span class="ligther">Brut majeur</span>75cl
          </p>
          <span></span>
          <p class="price">60.00€</p>
        </div>
      </div>
    </section>
    <Newsletter />
  </main>
</template>

<script>
import Newsletter from '../../components/default/Newsletter'
export default {
  components: {
    Newsletter
  }
}
</script>

<style scoped>
.ligther {
  font-weight: lighter;
  background-color: transparent !important;
}

.top_bar_fixed {
  position: fixed;
  right: 0;
  left: 0;
  top: 70px;
  height: 50px;
  background-color: var(--background);
  border-bottom: 1px solid #e0e0e0;
}

.container_items {
  height: 110px;
  overflow-x: scroll;
  background-color: var(--background);
  display: flex;
  flex-flow: column nowrap;
  border-bottom: 1px solid #e0e0e0;

  padding: 40px 0px 10px 20px;
}

.title p {
  color: var(--body);
  font-weight: bold;
  font-size: 14px;
}

.items {
  display: flex;
  margin-top: 10px;
  padding-bottom: 15px;
  overflow-x: scroll;
  flex-flow: row nowrap;
}

.items a {
  margin-right: 10px;
  text-decoration: none;
  color: var(--black);
  font-weight: bold;
  font-family: 'Noto', serif;
}

.nuxt-link-active {
  color: var(--redBody) !important;
  font-weight: bold !important;
}

.item_img {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 30px;
  height: 30px;
}

.item_img img {
  width: 100%;
}

.menu {
  padding: 150px 0 30px 0;
  background-image: url('~assets/img/jpg/back_bois.png');
  background-repeat: repeat;
  background-size: 100%;
}

.blackBody {
  padding: 20px;
  margin-top: 30px;
  margin-bottom: 20px;
  border-bottom: 2px solid var(--black);
  border-top: 2px solid var(--black);
}

.blackBody .title h2 {
  text-align: center;
  color: var(--black);
  font-size: 24px;
  font-style: italic;
  font-weight: bold;
  text-transform: uppercase;
  font-family: 'Times New Roman', Times, serif, sans-serif;
}

.blackBody_1 {
  padding: 20px;
  margin-top: 30px;
  margin-bottom: 20px;
  border-bottom: 2px solid var(--black);
  border-top: 2px solid var(--black);
}

.blackBody_1 .title h2 {
  text-align: center;
  color: var(--black);
  font-size: 24px;
  text-transform: none;
  font-family: 'italic-title', sans-serif;
}

.redBackground_1 {
  background-color: var(--redBody);
  padding: 20px;
  margin-top: 30px;
  border-top: 2px solid var(--black);
  margin-bottom: 20px;
  border-bottom: 2px solid var(--black);
}

.redBackground_1 .title h2 {
  text-align: center;
  color: var(--white);
  font-size: 28px;
  font-weight: bold;
  text-transform: none;
  font-family: 'italic-title';
}

.greenBody {
  border-top: 2px solid var(--black);
  padding: 20px;
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.greenBody .title h2 {
  text-align: center;
  color: var(--green);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.redBody {
  border-top: 2px solid var(--black);
  padding: 20px;
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.redBody .title h2 {
  text-align: center;
  color: var(--redBody);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.greenBackground {
  border-top: 2px solid var(--black);
  padding: 20px;
  background-color: var(--green);
  margin-bottom: 20px;
  margin-top: 30px;
  border-bottom: 2px solid var(--black);
}

.greenBackground .title h2 {
  text-align: center;
  color: var(--white);
  font-size: 32px;
  font-weight: bold;
  text-transform: none;
  font-family: 'Noto';
}

.elements_menu {
  display: flex;
  margin: 5px 20px;
  justify-content: space-between;
  align-items: flex-end;
}

.elements_menu .content {
  width: 100%;
  color: var(--black);
  font-weight: bold;
}

.elements_menu span {
  height: 1px;
  margin-right: 10px;
  border: none;
  margin-bottom: 7px;
  background-color: var(--black);
}

.elements_menu .price {
  color: var(--black);
  font-weight: lighter;
}

.content_menu .description {
  font-size: 12px;
  font-weight: lighter;
  margin: -5px 20px 0 20px;
  line-height: 20px;
  color: var(--black);
}

.accompagnement {
  margin: 10px 20px;
}

.accompagnement p {
  color: var(--redBody);
  font-size: lighter;
}

.accompagnement_green {
  margin: 10px 20px;
}

.accompagnement_green p {
  color: var(--green);
  font-size: lighter;
}
</style>
