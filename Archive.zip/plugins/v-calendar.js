import Vue from 'vue'
import Vcalendar from 'v-calendar'


Vue.use(Vcalendar, {             // second is optional
})